<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Libros Online</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
</head>

<body>
    <nav class="menu">
        <img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="" class="logo">
        <ul class="menu_items">
            <li><a href="#pro">¿Quienes Somos?</a></li>
            <li><a href="#contact">Contactenos</a></li>
        </ul>
        <div id="hamburguer">
            <button>
                <span class="top-line"></span>
                <span class="middle-line"></span>
                <span class="bottom-line"></span>
            </button>
        </div>
    </nav>
    <div class="registro">
        <h1>Registro del paciente para descargar el libro.</h1>

        <form action="<?php echo e(route('cliente.registrar')); ?>" method="POST">
        <?php if(session('mensaje')): ?>
        <div class="alert" role="alert">
            <?php echo e(session('mensaje')); ?>

        </div>
                <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div>
            <label for="apellidoM">Folio del médico</label>
            <input type="text" placeholder="Ingrese el N° de folio" id="folio_doctor" name="folio" value="<?php echo e(old('folio')); ?>" />
            <?php $__errorArgs = ['folio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="error"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
            <div>
                <label for="nombre">Nombre Doctor</label>
                <input type="text" placeholder="Ingresa el nombre de su doctor" id="nombre_doctor" name="nombre_doctor" value="<?php echo e(old('nombre_doctor')); ?>"/>
                <?php $__errorArgs = ['nombre_doctor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="apellidoP">Nombre Paciente </label>
                <input type="text" placeholder="Ingrese su nombre" id="apellidoP" name="nombre_paciente" value="<?php echo e(old('nombre_paciente')); ?>" />
                <?php $__errorArgs = ['nombre_paciente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <div>
                <label for="email">Email</label>
                <input type="email" placeholder="Ingresa tu email" id="email" name="email" value="<?php echo e(old('email')); ?>" />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="celular">Celular</label>
                <input type="text" placeholder="Ingresa tu numero de celular" id="celular" name="celular" value="<?php echo e(old('celular')); ?>" />
                <?php $__errorArgs = ['celular'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="celular">Código Postal</label>
                <input type="text" placeholder="Ingrese el código postal" id="codigo_postal" name="codigo" value="<?php echo e(old('codigo')); ?>" />
                <?php $__errorArgs = ['codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="celular">Alcaldia/Municipio</label>
                <input type="text" placeholder="Ingrese el código postal" id="alcaldia"  name="alcaldia" value="<?php echo e(old('alcaldia')); ?>" />
                <?php $__errorArgs = ['alcaldia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="celular">Ciudad</label>
                <input type="text" placeholder="Ingrese el código postal" id="ciudad"  name="ciudad" value="<?php echo e(old('ciudad')); ?>"/>
                <?php $__errorArgs = ['ciudad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="celular">Estado</label>
                <input type="text" placeholder="Ingrese el código postal" id="estado" name="estado" value="<?php echo e(old('estado')); ?>" />
                <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <input type="hidden" value="12345" name="password">
            <input type="submit" value="Registrarse" class="registrar" />
        </form>
    </div>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(asset('js/index.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
     <script src="<?php echo e(asset('js/buscador.js')); ?>"></script>
     <script src="<?php echo e(asset('js/BuscadorFolio.js')); ?>"></script>
     <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
</body>

</html>
<?php /**PATH C:\Users\jhers\Desktop\calibros\resources\views/auth-cliente/register.blade.php ENDPATH**/ ?>