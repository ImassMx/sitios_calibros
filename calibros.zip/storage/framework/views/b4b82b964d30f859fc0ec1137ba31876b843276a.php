<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>NOMBRE</th>
            <th>APELLIDOS</th>
            <th>ESPECIALIDAD</th>
            <th>FOLIO</th>
            <th>LIGA</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $doctores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
                <td><?php echo e($doctor->id); ?></td>
                <td><?php echo e($doctor->nombre); ?></td>
                <td><?php echo e($doctor->apellidos); ?></td>
                <td>
                    <?php echo e($doctor->especialidad->nombre); ?>

                </td>
                <td><?php echo e($doctor->folio); ?></td>
                <td>
                    <?php echo e($doctor->ligas->nombre); ?>

                </td>
        </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\jhers\Desktop\Repositorio 789\calibros\resources\views/export/Doctores.blade.php ENDPATH**/ ?>