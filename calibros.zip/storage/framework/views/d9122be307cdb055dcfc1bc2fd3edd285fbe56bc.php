<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Libros Online</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
</head>

<body>
    <nav class="menu">
        <img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="" class="logo">
        <ul class="menu_items">
            <?php if(auth()->guard()->check()): ?>
           <form method="POST" action="<?php echo e(route('logout.cliente')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit"  class="logout">Cerrar Session</button>
            </form>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <li><a href="#pro">¿Quienes Somos?</a></li>
            <li><a href="#contact">Contactenos</a></li>
            <?php endif; ?>
        </ul>
        <div id="hamburguer">
            <button>
                <span class="top-line"></span>
                <span class="middle-line"></span>
                <span class="bottom-line"></span>
            </button>
        </div>
    </nav>

    <div class="descargas container">
        <div class="content-descargas">
            <?php if($libro->estado === 1): ?>
                <h2><?php echo e($libro->nombre); ?></h2>
            <div class="cuerpo-descargas">
                <div class="image">
                    <img src="<?php echo e(asset('/admin/portada/' . $libro->portada)); ?>" alt="">
                </div>
                <div class="descripcion">
                    <p><?php echo e($libro->descripcion); ?></p>

                    <a href="<?php echo e(asset('libros/' . $libro->pdf)); ?>" id="descargar-libro"
                        download="<?php echo e($libro->nombre . '.pdf'); ?>">Descargar</a>
                    <input type="hidden" value="<?php echo e($libro->descargas); ?>" id="numerodescarga">
                    <input type="hidden" value="<?php echo e(auth()->user()->id); ?>" id="id_usuario">
                    <input type="hidden" value="<?php echo e($libro->id); ?>" id="id_libro">
                </div>
            </div>
            <?php else: ?>
                <h2>El contenido ya no esta disponible</h2>
            <?php endif; ?>
            <hr>
        </div>
        
    </div>
    <script src="<?php echo e(asset('js/index.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
      <script src="<?php echo e(asset('js/libros.js')); ?>"></script>

    <style>
        .logout{
            background:rgba(0,0,0,0);
            border:none;
            font-size:1rem;
        }
    </style>
</body>

</html>
<?php /**PATH C:\Users\jhers\Desktop\calibros\resources\views/principal/app.blade.php ENDPATH**/ ?>