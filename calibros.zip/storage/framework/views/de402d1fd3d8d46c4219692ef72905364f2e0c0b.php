<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

</head>

<body>

    <main class="login">
        <?php if(session('mensaje')): ?>
            <div class="alert alert-success" role="alert">
                <p class="error"><?php echo e(session('mensaje')); ?></p>
            </div>
        <?php endif; ?>
        <div class="contenido">
            <img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="">
            <div class="body-login">
                <form action="<?php echo e(route('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="inputs">
                        <label for="">Usuario</label>
                        <input type="text" placeholder="Ingresa tu usuario" name="email" value="<?php echo e(old('email')); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="inputs">
                        <label for="">Contraseña</label>
                        <input type="password" placeholder="Ingresa tu contraseña" name="password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <input type="submit" value="INGRESAR" class="ingresar">
                </form>
            </div>
        </div>
    </main>

    <script src="<?php echo e(asset('js/index.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\jhers\Desktop\Repositorio 789\calibros\resources\views/auth/login.blade.php ENDPATH**/ ?>